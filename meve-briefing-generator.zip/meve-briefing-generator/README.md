# Me Vê Um Site - Briefing Generator

Projeto para gerar briefings comerciais reutilizáveis da **Me Vê Um Site** em PDF e imagens PNG.

O design segue uma identidade visual escura, tecnológica, azul neon e premium, ideal para apresentações comerciais de sistemas personalizados, automações, dashboards e soluções digitais.

## O que o projeto gera

Ao rodar o projeto, ele cria automaticamente:

- `dist/briefing-comercial.pdf`
- `dist/briefing.html`
- `dist/briefing-page-1.png`
- `dist/briefing-page-2.png`
- `dist/briefing-page-3.png`
- `dist/briefing-page-4.png`

## Estrutura

```bash
meve-briefing-generator/
├── assets/
│   └── logo.png
├── data/
│   └── briefing.json
├── scripts/
│   └── generate-briefing.mjs
├── examples-output/
│   └── imagens de referência visual
├── dist/
├── package.json
└── README.md
```

## Instalação

```bash
npm install
npx playwright install chromium
```

## Gerar briefing

```bash
npm run generate
```

Os arquivos finais serão criados dentro da pasta `dist/`.

## Como editar o conteúdo

Altere apenas o arquivo:

```bash
data/briefing.json
```

Exemplo para adaptar para outro segmento:

```json
{
  "cover": {
    "subtitle": "Sistema Personalizado para Clínica Médica"
  }
}
```

Você pode trocar:

- título da apresentação
- segmento do cliente
- dores que o sistema resolve
- módulos da plataforma
- benefícios
- MVP recomendado
- frase de fechamento

## Como trocar a logo

Substitua o arquivo:

```bash
assets/logo.png
```

Mantenha o mesmo nome `logo.png` ou atualize o campo `brand.logoPath` no JSON.

## Como criar briefings diferentes

Você pode criar novos arquivos dentro de `data/`, por exemplo:

```bash
data/briefing-clinica.json
data/briefing-restaurante.json
data/briefing-imobiliaria.json
```

E gerar usando:

```bash
node scripts/generate-briefing.mjs --data data/briefing-clinica.json --out dist/clinica
```

## Observação

As imagens dentro da pasta `examples-output/` são referências visuais do modelo aprovado. O gerador oficial usa HTML/CSS para manter o texto nítido, a logo correta e o PDF reutilizável.
