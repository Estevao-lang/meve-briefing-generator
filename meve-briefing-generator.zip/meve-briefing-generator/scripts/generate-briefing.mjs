import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { chromium } from "playwright";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const root = path.resolve(__dirname, "..");
const pageWidth = 794;
const pageHeight = 1123;

function getArg(name, fallback) {
  const index = process.argv.indexOf(`--${name}`);
  if (index >= 0 && process.argv[index + 1]) return process.argv[index + 1];
  return fallback;
}

const dataPath = path.resolve(root, getArg("data", "data/briefing.json"));
const outputDir = path.resolve(root, getArg("out", "dist"));
const htmlPath = path.join(outputDir, "briefing.html");
const pdfPath = path.join(outputDir, "briefing-comercial.pdf");

function escapeHtml(value = "") {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function assetUrl(relativePath) {
  return pathToFileURL(path.join(root, relativePath)).href;
}

function icon(type) {
  const icons = {
    users: `<svg viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`,
    building: `<svg viewBox="0 0 24 24"><path d="M3 21h18"/><path d="M5 21V7l8-4v18"/><path d="M19 21V11l-6-4"/><path d="M9 9h1M9 13h1M9 17h1M14 13h1M14 17h1"/></svg>`,
    file: `<svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M9 13h6M9 17h6"/></svg>`,
    chart: `<svg viewBox="0 0 24 24"><path d="M3 3v18h18"/><path d="M7 16v-4M12 16V8M17 16v-7"/><path d="m7 10 5-5 5 3 4-5"/></svg>`,
    target: `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>`,
    gear: `<svg viewBox="0 0 24 24"><path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V22a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 20.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 3.6a1.65 1.65 0 0 0 1-1.51V2a2 2 0 1 1 4 0v.09A1.65 1.65 0 0 0 15 3.6a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.14.31.54 1 1.51 1H21a2 2 0 1 1 0 4h-.09c-.97 0-1.37.69-1.51 1Z"/></svg>`,
    hardhat: `<svg viewBox="0 0 24 24"><path d="M2 18h20"/><path d="M4 18a8 8 0 0 1 16 0"/><path d="M9 10v8M15 10v8"/><path d="M12 6v12"/></svg>`,
    rocket: `<svg viewBox="0 0 24 24"><path d="M4.5 16.5c-1 1.3-1.5 2.8-1.5 4.5 1.7 0 3.2-.5 4.5-1.5"/><path d="M9 15 4 20"/><path d="M15 9l-6 6"/><path d="M14 4c2.5-1.2 5-1 7-1-.1 2-.2 4.5-1.5 7L14 4Z"/><path d="M14 4 9 9l6 6 4.5-5"/></svg>`
  };
  return icons[type] || icons.target;
}

function listItem(text, iconType = "target") {
  return `<li><span class="mini-icon">${icon(iconType)}</span><span>${escapeHtml(text)}</span></li>`;
}

function moduleCard(module) {
  return `
    <div class="module-card">
      <div class="icon-circle">${icon(module.icon)}</div>
      <div>
        <h3>${escapeHtml(module.title)}</h3>
        <p>${escapeHtml(module.description)}</p>
      </div>
    </div>`;
}

function createHtml(data) {
  const logo = assetUrl(data.brand.logoPath || "assets/logo.png");

  return `<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${escapeHtml(data.cover.titleLine1)} ${escapeHtml(data.cover.titleLine2)}</title>
  <style>
    @page { size: A4; margin: 0; }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      background: #020814;
      font-family: Inter, Segoe UI, Arial, sans-serif;
      color: #fff;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    .page {
      width: ${pageWidth}px;
      height: ${pageHeight}px;
      position: relative;
      overflow: hidden;
      page-break-after: always;
      padding: 56px;
      background:
        radial-gradient(circle at 50% 10%, rgba(0, 173, 255, .30), transparent 30%),
        radial-gradient(circle at 8% 88%, rgba(0, 111, 255, .25), transparent 26%),
        linear-gradient(145deg, #020817 0%, #041638 55%, #020814 100%);
    }
    .page::before {
      content: "";
      position: absolute;
      inset: 0;
      background-image:
        linear-gradient(rgba(0, 195, 255, .045) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0, 195, 255, .045) 1px, transparent 1px);
      background-size: 42px 42px;
      opacity: .75;
      pointer-events: none;
    }
    .page::after {
      content: "";
      position: absolute;
      left: -10%;
      bottom: -12%;
      width: 120%;
      height: 250px;
      background:
        radial-gradient(ellipse at center, rgba(0, 211, 255, .32), transparent 62%),
        repeating-linear-gradient(165deg, transparent 0 13px, rgba(0, 191, 255, .22) 14px, transparent 16px);
      border-top: 1px solid rgba(0, 221, 255, .35);
      opacity: .95;
      pointer-events: none;
    }
    .content { position: relative; z-index: 2; height: 100%; }
    h1, h2, h3, p { margin: 0; }
    svg { width: 54px; height: 54px; stroke: #00caff; stroke-width: 1.8; fill: none; stroke-linecap: round; stroke-linejoin: round; }
    .logo { width: 150px; height: auto; object-fit: contain; filter: drop-shadow(0 0 18px rgba(0, 176, 255, .7)); }
    .small-logo { width: 124px; filter: drop-shadow(0 0 14px rgba(0, 176, 255, .65)); }
    .topbar { display: flex; align-items: center; justify-content: space-between; gap: 28px; margin-bottom: 34px; }
    .page-badge { border: 1px solid rgba(0, 211, 255, .75); color: #dff8ff; border-radius: 11px; padding: 9px 15px; font-size: 13px; letter-spacing: .08em; background: rgba(0, 22, 50, .65); box-shadow: 0 0 18px rgba(0, 194, 255, .15); }
    .blueprint { position: absolute; right: 38px; top: 96px; width: 320px; height: 260px; border-bottom: 1px solid rgba(0, 191, 255, .18); opacity: .52; z-index: 1; }
    .building { position: absolute; bottom: 0; border: 1px solid rgba(0, 179, 255, .55); box-shadow: inset 0 0 18px rgba(0, 157, 255, .12); background: repeating-linear-gradient(0deg, transparent 0 18px, rgba(0, 190, 255, .24) 19px 20px); }
    .b1 { left: 30px; width: 65px; height: 165px; }
    .b2 { left: 105px; width: 74px; height: 210px; }
    .b3 { left: 190px; width: 55px; height: 135px; }
    .crane { position: absolute; right: 10px; top: 20px; width: 150px; height: 70px; border-top: 2px solid rgba(0, 195, 255, .6); transform: rotate(-8deg); }
    .crane::after { content: ""; position: absolute; right: 8px; top: 0; height: 90px; border-right: 2px solid rgba(0, 195, 255, .5); }
    .dashboard-bg { position: absolute; right: 52px; top: 176px; width: 260px; height: 190px; border: 1px solid rgba(0, 213, 255, .18); border-radius: 18px; background: rgba(2, 15, 37, .38); box-shadow: inset 0 0 40px rgba(0, 194, 255, .08); opacity: .55; z-index: 1; }
    .dashboard-bg::before { content: ""; position: absolute; left: 24px; top: 36px; width: 200px; height: 70px; background: linear-gradient(140deg, transparent 0 18%, rgba(0, 208, 255, .55) 19% 22%, transparent 23% 38%, rgba(0, 208, 255, .75) 39% 42%, transparent 43%); border-bottom: 1px solid rgba(0, 210, 255, .25); }
    .dashboard-bg::after { content: ""; position: absolute; left: 30px; bottom: 28px; width: 200px; height: 52px; background: repeating-linear-gradient(90deg, rgba(0, 191, 255, .55) 0 16px, transparent 17px 32px); opacity: .65; }
    .hero-logo-wrap { display: flex; justify-content: center; margin-top: 34px; margin-bottom: 64px; }
    .hero-logo { width: 355px; filter: drop-shadow(0 0 34px rgba(0, 200, 255, .95)); }
    .hero-logo-ring { position: relative; display: grid; place-items: center; width: 470px; height: 315px; }
    .hero-logo-ring::before { content: ""; position: absolute; width: 390px; height: 390px; border-radius: 50%; border: 1px solid rgba(0, 213, 255, .28); box-shadow: 0 0 70px rgba(0, 198, 255, .32), inset 0 0 60px rgba(0, 198, 255, .18); }
    .cover-title { text-align: center; margin-top: 18px; }
    .cover-title h1 { font-size: 78px; line-height: .92; letter-spacing: -0.055em; font-weight: 900; }
    .cover-title h1 span { display: block; font-size: 92px; color: #00c8ff; text-shadow: 0 0 22px rgba(0, 198, 255, .5); }
    .cover-subtitle { margin-top: 20px; font-size: 24px; color: #effbff; letter-spacing: -.02em; }
    .feature-bar { margin: 36px auto 34px; max-width: 690px; border: 1px solid #00d2ff; border-radius: 16px; padding: 16px 20px; background: rgba(0, 18, 44, .76); display: flex; align-items: center; justify-content: center; flex-wrap: wrap; gap: 12px 14px; box-shadow: 0 0 30px rgba(0, 191, 255, .16); font-size: 14px; }
    .feature-bar span { color: #eefcff; }
    .feature-bar b { color: #00cdfa; }
    .cover-message { max-width: 650px; text-align: center; margin: 0 auto; color: #e7f7ff; font-size: 22px; line-height: 1.42; }
    .cover-message strong { color: #00caff; }
    .footer { position: absolute; left: 56px; right: 56px; bottom: 50px; z-index: 3; display: flex; align-items: center; justify-content: center; gap: 18px; color: #f3fbff; font-size: 17px; background: rgba(1, 16, 38, .48); border: 1px solid rgba(0, 200, 255, .3); border-radius: 14px; padding: 13px 18px; }
    .footer b { font-weight: 800; }
    .footer .divider { width: 1px; height: 22px; background: #00caff; }
    .footer .muted { color: #cbd9e8; }
    .section-title { margin-top: 8px; margin-bottom: 34px; display: grid; grid-template-columns: auto 1fr; align-items: center; gap: 26px; }
    .section-title .line { width: 2px; height: 86px; background: linear-gradient(#00d5ff, transparent); }
    .section-title h2 { font-size: 56px; font-weight: 900; letter-spacing: -.05em; line-height: .98; }
    .section-title p { margin-top: 8px; font-size: 28px; color: #00bfff; }
    .panel { position: relative; border: 1px solid rgba(0, 204, 255, .72); border-radius: 18px; background: rgba(1, 15, 37, .76); box-shadow: 0 0 26px rgba(0, 186, 255, .12), inset 0 0 50px rgba(0, 151, 255, .06); padding: 28px 30px; margin-bottom: 16px; }
    .panel-row { display: grid; grid-template-columns: 128px 1fr; gap: 24px; align-items: center; }
    .big-icon { width: 105px; height: 105px; border-radius: 50%; display: grid; place-items: center; background: radial-gradient(circle, rgba(0, 200, 255, .16), rgba(0, 40, 90, .18)); border: 1px solid rgba(0, 208, 255, .32); }
    .panel h3 { font-size: 28px; margin-bottom: 12px; font-weight: 850; letter-spacing: -.02em; }
    .panel h3 .num { color: #00caff; }
    .panel p { color: #edf8ff; font-size: 20px; line-height: 1.35; }
    .pain-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px 32px; margin-top: 18px; list-style: none; padding: 0; }
    .pain-grid li, .benefit-list li, .mvp-list li { display: flex; align-items: center; gap: 16px; color: #eefaff; font-size: 18px; line-height: 1.25; min-height: 54px; border-bottom: 1px solid rgba(0, 187, 255, .15); }
    .mini-icon { width: 50px; height: 50px; flex: 0 0 50px; display: grid; place-items: center; border-radius: 14px; border: 1px solid rgba(0, 203, 255, .35); background: rgba(0, 91, 190, .12); }
    .mini-icon svg { width: 28px; height: 28px; }
    .quote-box { margin-top: 18px; display: grid; grid-template-columns: 85px 1fr; gap: 16px; align-items: center; border: 1px solid rgba(0, 211, 255, .8); border-radius: 18px; padding: 24px; background: rgba(0, 24, 58, .78); box-shadow: 0 0 32px rgba(0, 191, 255, .2); }
    .quote-mark { width: 70px; height: 70px; border: 1px solid #00caff; border-radius: 50%; display: grid; place-items: center; color: #00caff; font-size: 54px; font-weight: 900; }
    .quote-box p { font-size: 23px; line-height: 1.35; }
    .quote-box strong { color: #00caff; }
    .modules-title { margin-top: 92px; margin-bottom: 28px; }
    .modules-title h2 { font-size: 62px; line-height: .95; font-weight: 900; letter-spacing: -.055em; }
    .modules-title h2 span { color: #00caff; display: block; }
    .modules-title p { margin-top: 14px; font-size: 22px; color: #effbff; }
    .modules-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 18px; }
    .module-card { min-height: 136px; display: grid; grid-template-columns: 86px 1fr; gap: 20px; align-items: center; border: 1px solid rgba(0, 204, 255, .68); border-radius: 18px; background: rgba(1, 15, 37, .76); padding: 22px; box-shadow: inset 0 0 45px rgba(0, 191, 255, .05); }
    .icon-circle { width: 76px; height: 76px; border-radius: 50%; display: grid; place-items: center; border: 1px solid rgba(0, 204, 255, .6); background: rgba(0, 84, 180, .13); }
    .icon-circle svg { width: 42px; height: 42px; }
    .module-card h3 { font-size: 22px; line-height: 1.08; margin-bottom: 8px; }
    .module-card p { color: #d9ebf7; font-size: 15.5px; line-height: 1.28; }
    .bottom-highlight { margin-top: 22px; border: 1px solid #00caff; border-radius: 18px; background: rgba(0, 24, 58, .78); padding: 20px 26px; display: grid; grid-template-columns: 70px 1fr; gap: 20px; align-items: center; color: #00d5ff; font-size: 22px; line-height: 1.28; }
    .benefits-layout { display: grid; grid-template-columns: 1.22fr .92fr; gap: 22px; margin-top: 50px; }
    .label { display: inline-flex; align-items: center; gap: 12px; background: rgba(0, 43, 95, .88); border: 1px solid rgba(0, 202, 255, .6); border-radius: 12px; padding: 9px 15px; font-weight: 800; margin-bottom: 8px; }
    .label span { background: linear-gradient(135deg, #00d7ff, #006dff); padding: 5px 10px; border-radius: 7px; }
    .benefit-list, .mvp-list { list-style: none; padding: 18px 22px; margin: 0; border: 1px solid rgba(0, 204, 255, .62); border-radius: 18px; background: rgba(1, 15, 37, .78); min-height: 388px; }
    .mvp-list li { font-size: 17px; }
    .closing-quote { margin-top: 24px; text-align: center; border: 1px solid rgba(0, 210, 255, .7); border-radius: 18px; background: rgba(1, 18, 45, .78); padding: 30px 50px; font-size: 27px; line-height: 1.28; }
    .closing-quote strong { color: #00caff; }
    .cta { margin-top: 24px; display: grid; grid-template-columns: 84px 1fr; align-items: center; gap: 24px; border: 1px solid #00caff; border-radius: 18px; padding: 24px 42px; background: rgba(0, 25, 61, .82); }
    .cta p { font-size: 32px; font-weight: 850; letter-spacing: -.03em; }
    .cta strong { color: #00caff; display: block; }
  </style>
</head>
<body>
  <section class="page" id="page-1">
    <div class="blueprint"><div class="building b1"></div><div class="building b2"></div><div class="building b3"></div><div class="crane"></div></div>
    <div class="dashboard-bg"></div>
    <div class="content">
      <div class="hero-logo-wrap"><div class="hero-logo-ring"><img class="hero-logo" src="${logo}" alt="${escapeHtml(data.brand.name)}" /></div></div>
      <div class="cover-title"><h1>${escapeHtml(data.cover.titleLine1)}<span>${escapeHtml(data.cover.titleLine2)}</span></h1><p class="cover-subtitle">${escapeHtml(data.cover.subtitle)}</p></div>
      <div class="feature-bar">${data.cover.features.map((item) => `<span><b>•</b> ${escapeHtml(item)}</span>`).join("")}</div>
      <p class="cover-message">${escapeHtml(data.brand.mainMessagePrefix)} <strong>${escapeHtml(data.brand.mainMessageHighlight)}</strong></p>
      <div class="footer"><b>${escapeHtml(data.brand.name)}</b><span class="divider"></span><span class="muted">Software House</span></div>
    </div>
  </section>

  <section class="page" id="page-2">
    <div class="blueprint"><div class="building b1"></div><div class="building b2"></div><div class="building b3"></div><div class="crane"></div></div>
    <div class="content">
      <div class="topbar"><img class="small-logo" src="${logo}" alt="${escapeHtml(data.brand.name)}" /><div class="page-badge">PÁGINA 02</div></div>
      <div class="section-title"><span class="line"></span><div><h2>Quem Somos</h2><p>Objetivo da Solução</p></div></div>
      <div class="panel panel-row"><div class="big-icon">${icon("users")}</div><div><h3><span class="num">1.</span> Quem Somos</h3><p>${escapeHtml(data.about.company)}</p></div></div>
      <div class="panel panel-row"><div class="big-icon">${icon("target")}</div><div><h3><span class="num">2.</span> Objetivo da Solução</h3><p>${escapeHtml(data.about.objective)}</p></div></div>
      <div class="panel"><h3><span class="num">3.</span> Principais dores que resolvemos</h3><ul class="pain-grid">${data.about.pains.map((pain, index) => listItem(pain, ["file", "gear", "building", "users", "target", "chart"][index] || "target")).join("")}</ul></div>
      <div class="quote-box"><div class="quote-mark">“</div><p><strong>Não criamos apenas sites.</strong> Criamos soluções digitais para empresas <strong>venderem mais, organizarem processos e crescerem com tecnologia.</strong></p></div>
      <div class="footer"><span>${escapeHtml(data.brand.website)}</span><span class="divider"></span><b>${escapeHtml(data.brand.name)}</b></div>
    </div>
  </section>

  <section class="page" id="page-3">
    <div class="blueprint"><div class="building b1"></div><div class="building b2"></div><div class="building b3"></div><div class="crane"></div></div>
    <div class="dashboard-bg"></div>
    <div class="content">
      <div class="topbar"><img class="small-logo" src="${logo}" alt="${escapeHtml(data.brand.name)}" /><div class="page-badge">03</div></div>
      <div class="modules-title"><h2>Módulos da<span>Plataforma</span></h2><p>Solução sob medida para construtora e imobiliária</p></div>
      <div class="modules-grid">${data.modules.map(moduleCard).join("")}</div>
      <div class="bottom-highlight"><div class="icon-circle">${icon("target")}</div><p>O sistema pode ser desenvolvido por módulos, de acordo com a necessidade e a operação da empresa.</p></div>
      <div class="footer"><span>${escapeHtml(data.brand.website)}</span><span class="divider"></span><b>${escapeHtml(data.brand.name)}</b></div>
    </div>
  </section>

  <section class="page" id="page-4">
    <div class="blueprint"><div class="building b1"></div><div class="building b2"></div><div class="building b3"></div><div class="crane"></div></div>
    <div class="content">
      <div class="topbar"><img class="small-logo" src="${logo}" alt="${escapeHtml(data.brand.name)}" /><div class="page-badge">4 / 4</div></div>
      <div class="modules-title"><h2>Benefícios e<span>Próximos Passos</span></h2></div>
      <div class="benefits-layout">
        <div><div class="label"><span>1</span> Benefícios para a empresa:</div><ul class="benefit-list">${data.benefits.map((benefit, index) => listItem(benefit, ["target", "gear", "users", "file", "chart", "building"][index] || "target")).join("")}</ul></div>
        <div><div class="label"><span>2</span> MVP Recomendado:</div><ul class="mvp-list">${data.mvp.map((item, index) => listItem(item, ["users", "building", "file", "chart", "users"][index] || "target")).join("")}</ul></div>
      </div>
      <div class="closing-quote">Ajudamos construtoras e imobiliárias a saírem das planilhas e centralizarem sua operação em uma <strong>plataforma moderna, organizada e sob medida.</strong></div>
      <div class="cta"><div class="icon-circle">${icon("rocket")}</div><p>Vamos transformar sua operação <strong>em uma solução digital personalizada?</strong></p></div>
      <div class="footer"><b>${escapeHtml(data.brand.name)}</b><span class="divider"></span><span class="muted">Sistemas personalizados • Automações • Sites profissionais</span><span class="divider"></span><span>${escapeHtml(data.brand.website)}</span></div>
    </div>
  </section>
</body>
</html>`;
}

async function main() {
  await fs.mkdir(outputDir, { recursive: true });
  const data = JSON.parse(await fs.readFile(dataPath, "utf8"));
  const htmlContent = createHtml(data);
  await fs.writeFile(htmlPath, htmlContent, "utf8");

  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: pageWidth, height: pageHeight }, deviceScaleFactor: 2 });
  await page.goto(pathToFileURL(htmlPath).href, { waitUntil: "networkidle" });

  await page.pdf({
    path: pdfPath,
    width: `${pageWidth}px`,
    height: `${pageHeight}px`,
    printBackground: true,
    margin: { top: "0", right: "0", bottom: "0", left: "0" }
  });

  for (let index = 1; index <= 4; index++) {
    const locator = page.locator(`#page-${index}`);
    await locator.screenshot({
      path: path.join(outputDir, `briefing-page-${index}.png`),
      animations: "disabled"
    });
  }

  await browser.close();
  console.log("Briefing gerado com sucesso!");
  console.log(`PDF: ${pdfPath}`);
  console.log(`HTML: ${htmlPath}`);
  console.log(`Imagens: ${outputDir}/briefing-page-1.png até briefing-page-4.png`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
